import { useEffect, useState } from "react";

import Signup from "./pages/signup";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import Login from "./pages/login";
import Products from "./pages/products";

function App() {
  // const [products, setProducts] = useState(null);
  // const [loading, setLoading] = useState(true);
  // const [error, setError] = useState(null);
  // const [image, setImage] = useState(null);

  // async function fetchData() {
  //   const response = await fetch(
  //     "http://localhost:8000/shop/product?color=white&price=425000"
  //   );
  //   const data = await response.json();
  //   const prod = data.map((product) => {
  //     product.imageUrl = "http://localhost:8000/" + product.imageUrl;
  //     return product;
  //   });
  //   console.log(prod)
  //   setProducts(prod);
  // }
  // useEffect(() => {
  //   fetchData();
  // }, []);
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <>
              <div>
                <Link to="/signup">SignUp</Link>
              </div>
              <div>
                <Link to="/login">SignIn</Link>
              </div>
            </>
          }
        />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/products" element={<Products />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
