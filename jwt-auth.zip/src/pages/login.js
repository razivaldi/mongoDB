import { Card, Input, Button, Typography } from "@material-tailwind/react";
import { useState } from "react";

export default function Login() {
  const [user, setUser] = useState({ email: "", password: "" });
  async function fetchToken() {
    await fetch("http://localhost:8000/auth/login", {
      crossDomain: true,
      method: "POST",
      body: `email=${user.email}&password=${user.password}`,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })
      .then((res) => res.json())
      .then((data) => {
        localStorage.setItem("token", data.token);
        console.log(data);
      })
      .then(() => {
        window.location.href = "/products";
      })
      .catch((err) => console.log(err));
  }

  const handleInput = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    // e.preventDefault();
    await fetchToken();
  };
  return (
    <div className="flex justify-center">
      <Card color="transparent" shadow={false}>
        <Typography variant="h4" color="blue-gray">
          Sign In
        </Typography>
        <Typography color="gray" className="mt-1 font-normal">
          Nice to meet you! Enter your details to register.
        </Typography>
        <form
          onSubmit={handleSubmit}
          className="mt-8 mb-2 w-80 max-w-screen-lg sm:w-96"
          method="POST"
          action="http://localhost:8000/auth/login"
        >
          <div className="mb-1 flex flex-col gap-6">
            <Typography variant="h6" color="blue-gray" className="-mb-3">
              Your Name
            </Typography>
            <Input
              size="lg"
              placeholder="name@mail.com"
              className=" !border-t-blue-gray-200 focus:!border-t-gray-900"
              labelProps={{
                className: "before:content-none after:content-none",
              }}
              name="email"
              onChange={handleInput}
            />
            <Typography variant="h6" color="blue-gray" className="-mb-3">
              Password
            </Typography>
            <Input
              type="password"
              size="lg"
              placeholder="********"
              className=" !border-t-blue-gray-200 focus:!border-t-gray-900"
              labelProps={{
                className: "before:content-none after:content-none",
              }}
              name="password"
              onChange={handleInput}
            />
          </div>
          <Button className="mt-6" fullWidth type="submit">
            Login
          </Button>
        </form>
      </Card>
    </div>
  );
}
