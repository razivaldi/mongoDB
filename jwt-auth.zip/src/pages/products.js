import { useEffect, useState } from "react";

export default function Products() {
  const [products, setProducts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const token = localStorage.getItem("token");
  async function fetchData() {
    await fetch("http://localhost:8000/shop/products", {
      method: "GET",
      crossDomain: true,
      headers: {
        Authorization: "Bearer " + token,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        console.log({ products: data });
        setProducts(data);
        setError(null);
      })
      .catch((err) => {
        setError(err.message);
        setProducts(null);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    console.log(products);
    fetchData()
  }, []);

  return (
    <div>
      kosong
      {loading && <h1>Loading....</h1>}
      {error && <h1>{error}</h1>}
      {products &&
        products.map((product) => {
          return <h1>{product.title}</h1>;
        })}
    </div>
  );
}
