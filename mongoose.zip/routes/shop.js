const express = require("express");
const router = express.Router();
const productsController = require("../controllers/products");
const cartController = require("../controllers/carts");
const shopController = require("../controllers/shop");

router.get("/", function (req, res) {
  res.send("Welcome Coding");
});

router.get("/products", productsController.getProducts);
// router.get("/product/:productId", productsController.getProduct);
router.get("/product", productsController.getProductByQuery);
router.get("/carts", cartController.getCarts);
router.post("/cart", cartController.postAddCart);
// router.post("/delete-cart", cartController.postDeleteCart);
// router.get("/get-cart", shopController.getCart);
// router.get("/product-detail/:productId", productsController.getProductDetail);
// router.post("/post-cart", shopController.postCart);
// router.get("/orders", shopController.getOrders);
// router.post("/create-order", shopController.postOrder);
// router.post("/delete-cart-product", shopController.deleteCartProduct);

router.use("/user/:id", (req, res, next) => {
  console.log("req tipe:", req.method);
  next();
});

router.get("/user/:id", (req, res, next) => {
  console.log("middleware2");
  next();
});

router.use(
  "/user/:id",
  (req, res, next) => {
    console.log("USER ID:", req.params.id);
    next();
  },
  (req, res, next) => {
    res.send("USER");
  }
);

module.exports = router;
