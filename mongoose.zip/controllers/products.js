const Product = require("../models/product");

exports.postAddProduct = (req, res, next) => {
  const title = req.body.title;
  const imageUrl = req.body.imageUrl;
  const price = req.body.price;
  const desc = req.body.description;
  const color = req.body.color;
  const category = req.body.category

  const product = new Product ({
    title: title,
    price : price, 
    imageUrl : imageUrl,
    description : desc,
    colors : color ,
    category : category,
  })

  product.save().then(result => {
    res.send(result)
  }).catch(err => console.log(err))
  
};

exports.getProducts = (req, res, next) => {
  // Product.find({ price : {$gte : 900000}}).then(products => {
  Product.find({ title : /jaket/i}, "title price colors ").then(products => {
    res.json(products)
  }).catch(err => console.log(err))
}

exports.getProductByQuery = (req, res, next) => {
  const { color, category, price } = req.query;

  Product.find({
    colors : color,
    category : category,
    price : price
  }).then(products => {
    if (products.length === 0) {
      return res.json({ status: 201, message: "Product not found" });
    }
    return res.json(products)
  }).catch(err => console.log(err))
}

